# TFARCENIM Load Function
tellraw @a {"text":"TFARCENIM 加载完成","color":"gold"}
tellraw @a {"text":"MINECRAFT 倒写 —— 你的经验在这里一文不值","color":"yellow"}
