# TFARCENIM Reward Chest Assist Function
# Mod handles primary reward chest logic; this is a datapack assist
# Places a bonus chest near spawn with starter items
# Items: wooden axe, book, leather, string, bread, torches
# This function is called by the mod on world load / player first join
tellraw @a {"text":"[TFARCENIM] 奖励箱已生成！","color":"aqua"}
# Note: Actual chest placement is handled by tfarcenim-core mod
