# TFARCENIM Undead No-Burn Assist Function
# Give all undead entities permanent fire resistance
# Called by tick function or mod as needed
effect give @e[type=#tfarcenim:undead] fire_resistance 1 0 true
