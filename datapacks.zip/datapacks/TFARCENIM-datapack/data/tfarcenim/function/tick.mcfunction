# TFARCENIM Tick Function
# Give undead entities that are on fire fire resistance (visual burn without damage)
# Full "no burn" is handled by mod; this is a datapack assist
execute as @e[type=#tfarcenim:undead,nbt={Fire:20s}] at @s run effect give @s fire_resistance 1 0 true
